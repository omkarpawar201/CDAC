#include <iostream>
using namespace std;

int main()
{

    int arr[] = {5, 3, 8, 1, 6};

    int n = 3;

    

    return 0;
}