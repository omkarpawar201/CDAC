public class Test {

    public static void main(String[] args) {
        int a = 12345;
        byte b = 127;

        b = (byte) a;

        System.out.println(b);

    }
}
